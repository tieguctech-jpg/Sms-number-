import { copyFileSync, existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { delimiter, resolve } from "node:path";
import { tmpdir } from "node:os";
import { spawnSync } from "node:child_process";

const required = [
  "ANDROID_KEYSTORE_PASSWORD",
  "ANDROID_KEY_PASSWORD",
];
const missing = required.filter((key) => !process.env[key]);

if (missing.length) {
  throw new Error(
    `Missing release configuration: ${missing.join(", ")}. Provide these through Replit Secrets or the build environment; never commit them.`,
  );
}

function run(command, args, cwd, env = process.env) {
  const result = spawnSync(command, args, {
    cwd,
    env,
    stdio: "inherit",
  });
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

const workspaceBackend = process.env.REPLIT_DEV_DOMAIN
  ? `https://${process.env.REPLIT_DEV_DOMAIN}`
  : undefined;
const apiOrigin =
  process.env.CORDOVA_API_ORIGIN ??
  process.env.EXPO_PUBLIC_API_URL ??
  workspaceBackend;

if (!apiOrigin) {
  throw new Error(
    "Missing backend URL. Set CORDOVA_API_ORIGIN or EXPO_PUBLIC_API_URL before building the release APK.",
  );
}

const releaseEnv = {
  ...process.env,
  CORDOVA_API_ORIGIN: apiOrigin,
  CORDOVA_API_URL: process.env.CORDOVA_API_URL ?? apiOrigin,
  ANDROID_KEYSTORE_PATH: resolve(
    process.env.ANDROID_KEYSTORE_PATH ?? "cordova/otp-market-upload.jks",
  ),
  ANDROID_KEY_ALIAS: process.env.ANDROID_KEY_ALIAS ?? "sms-number-upload",
};
releaseEnv.PATH = `${resolve("cordova/gradle-bin")}${delimiter}${process.env.PATH ?? ""}`;
const localSdk = resolve(".android-sdk");
if (existsSync(localSdk)) {
  releaseEnv.ANDROID_HOME ??= localSdk;
  releaseEnv.ANDROID_SDK_ROOT ??= localSdk;
  releaseEnv.PATH = [
    resolve(localSdk, "platform-tools"),
    resolve(localSdk, "cmdline-tools/latest/bin"),
    releaseEnv.PATH,
  ].join(delimiter);
}

if (!existsSync(releaseEnv.ANDROID_KEYSTORE_PATH)) {
  throw new Error(
    `Android release keystore not found: ${releaseEnv.ANDROID_KEYSTORE_PATH}. Run pnpm android:keystore first or set ANDROID_KEYSTORE_PATH to an existing keystore.`,
  );
}

run("node", ["scripts/build-cordova.mjs"], resolve("."), releaseEnv);

const cordovaDir = resolve("cordova");
const platformDir = resolve(cordovaDir, "platforms/android");
// Cordova prepare can update nested web assets without invalidating Gradle's
// incremental asset merge. Clean generated app outputs so the release package
// always contains the complete Expo export, not only the root HTML files.
rmSync(resolve(platformDir, "app/build"), { recursive: true, force: true });
const buildConfigDir = mkdtempSync(resolve(tmpdir(), "otp-market-cordova-"));
const buildConfigPath = resolve(buildConfigDir, "build.json");
const baseReleaseConfig = {
  keystore: releaseEnv.ANDROID_KEYSTORE_PATH,
  alias: releaseEnv.ANDROID_KEY_ALIAS,
  storePassword: releaseEnv.ANDROID_KEYSTORE_PASSWORD,
  password: releaseEnv.ANDROID_KEY_PASSWORD,
};

try {
  for (const packageType of ["apk", "bundle"]) {
    writeFileSync(
      buildConfigPath,
      JSON.stringify({ android: { release: { ...baseReleaseConfig, packageType } } }),
    );
    run(
      resolve("node_modules/.bin/cordova"),
      ["build", "android", "--release", `--buildConfig=${buildConfigPath}`],
      cordovaDir,
      releaseEnv,
    );
  }
} finally {
  rmSync(buildConfigDir, { recursive: true, force: true });
}

const apk = resolve(platformDir, "app/build/outputs/apk/release/app-release.apk");
const aab = resolve(platformDir, "app/build/outputs/bundle/release/app-release.aab");
if (!existsSync(apk) || !existsSync(aab)) {
  throw new Error("Gradle completed without producing both the Cordova release APK and AAB.");
}

const outputDir = resolve(cordovaDir, "release");
mkdirSync(outputDir, { recursive: true });
copyFileSync(apk, resolve(outputDir, "otp-market-cordova-release.apk"));
copyFileSync(aab, resolve(outputDir, "otp-market-cordova-release.aab"));
console.log(`Signed Cordova APK: ${resolve(outputDir, "otp-market-cordova-release.apk")}`);
console.log(`Signed Cordova AAB: ${resolve(outputDir, "otp-market-cordova-release.aab")}`);