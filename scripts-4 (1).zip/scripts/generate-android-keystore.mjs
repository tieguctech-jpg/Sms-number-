import { mkdirSync, existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { spawnSync } from "node:child_process";

const keystorePath = resolve(
  process.env.ANDROID_KEYSTORE_PATH ?? "cordova/otp-market-upload.jks",
);
const alias = process.env.ANDROID_KEY_ALIAS ?? "sms-number-upload";
const storePassword = process.env.ANDROID_KEYSTORE_PASSWORD;
const keyPassword = process.env.ANDROID_KEY_PASSWORD ?? storePassword;
const dname = process.env.ANDROID_KEY_DNAME
  ?? "CN=SMS Number, OU=Mobile, O=SMS Number, L=Unknown, ST=Unknown, C=NG";

if (!storePassword || !keyPassword) {
  throw new Error(
    "Set ANDROID_KEYSTORE_PASSWORD and ANDROID_KEY_PASSWORD through your environment or Replit Secrets before generating a release keystore.",
  );
}

if (existsSync(keystorePath)) {
  throw new Error(`Keystore already exists at ${keystorePath}. Set a different ANDROID_KEYSTORE_PATH or remove it deliberately.`);
}

mkdirSync(dirname(keystorePath), { recursive: true });
const result = spawnSync("keytool", [
  "-genkeypair",
  "-v",
  "-keystore",
  keystorePath,
  "-alias",
  alias,
  "-keyalg",
  "RSA",
  "-keysize",
  "2048",
  "-validity",
  "10000",
  "-storepass",
  storePassword,
  "-keypass",
  keyPassword,
  "-dname",
  dname,
], { stdio: "inherit" });

if (result.status !== 0) {
  process.exit(result.status ?? 1);
}

console.log(`Android release keystore created at ${keystorePath}`);