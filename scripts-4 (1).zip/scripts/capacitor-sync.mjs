import { spawnSync } from "node:child_process";

function getApiOrigin() {
  const configured = process.env.CAPACITOR_API_ORIGIN
    ?? process.env.REPLIT_INTERNAL_APP_DOMAIN
    ?? process.env.REPLIT_DEV_DOMAIN
    ?? process.env.EXPO_PUBLIC_DOMAIN;

  if (!configured) {
    throw new Error(
      "Set CAPACITOR_API_ORIGIN to the deployed SMS Number URL before building Android (for example, https://your-app.replit.app).",
    );
  }

  const origin = /^https?:\/\//i.test(configured) ? configured : `https://${configured}`;
  return new URL(origin).origin;
}

function run(command, args, env = process.env) {
  const result = spawnSync(command, args, {
    cwd: process.cwd(),
    env,
    stdio: "inherit",
  });

  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

const apiOrigin = getApiOrigin();
const apiDomain = new URL(apiOrigin).host;
const apiUrl = process.env.CAPACITOR_API_URL
  ?? process.env.EXPO_PUBLIC_API_URL
  ?? apiOrigin;
const buildEnv = {
  ...process.env,
  EXPO_PUBLIC_DOMAIN: apiDomain,
  EXPO_PUBLIC_API_URL: apiUrl,
  REPLIT_INTERNAL_APP_DOMAIN: apiDomain,
};

run("pnpm", ["--filter", "@workspace/mobile", "run", "build"], buildEnv);
run("pnpm", ["exec", "cap", "sync", "android"], buildEnv);