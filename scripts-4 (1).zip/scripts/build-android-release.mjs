import { existsSync, mkdirSync, copyFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { spawnSync } from "node:child_process";

const required = [
  "CAPACITOR_API_ORIGIN",
  "ANDROID_KEYSTORE_PATH",
  "ANDROID_KEY_ALIAS",
  "ANDROID_KEYSTORE_PASSWORD",
  "ANDROID_KEY_PASSWORD",
];
const missing = required.filter(key => !process.env[key]);

if (missing.length) {
  throw new Error(
    `Missing release configuration: ${missing.join(", ")}. Provide these through Replit Secrets or the build environment; never commit them.`,
  );
}

function run(command, args, env = process.env) {
  const result = spawnSync(command, args, {
    cwd: process.cwd(),
    env,
    stdio: "inherit",
  });

  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

const releaseEnv = {
  ...process.env,
  ANDROID_KEYSTORE_PATH: resolve(process.env.ANDROID_KEYSTORE_PATH),
};

run("node", ["scripts/capacitor-sync.mjs"], releaseEnv);
run("./android/gradlew", ["-p", "android", "assembleRelease", "bundleRelease"], releaseEnv);

const apk = resolve("android/app/build/outputs/apk/release/app-release.apk");
const aab = resolve("android/app/build/outputs/bundle/release/app-release.aab");
if (!existsSync(apk) || !existsSync(aab)) {
  throw new Error("Gradle completed without producing both the release APK and AAB.");
}

const outputDir = resolve("android/release");
mkdirSync(outputDir, { recursive: true });
copyFileSync(apk, resolve(outputDir, "sms-number-release.apk"));
copyFileSync(aab, resolve(outputDir, "sms-number-release.aab"));
console.log(`Signed APK: ${resolve(outputDir, "sms-number-release.apk")}`);
console.log(`Signed AAB: ${resolve(outputDir, "sms-number-release.aab")}`);