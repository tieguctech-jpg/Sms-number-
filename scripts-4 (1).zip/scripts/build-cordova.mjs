import {
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { delimiter, resolve } from "node:path";
import { spawnSync } from "node:child_process";

const root = resolve(".");
const mobileDir = resolve("artifacts/mobile");
const webDir = resolve(mobileDir, "static-build");
const cordovaDir = resolve("cordova");
const cordovaBin = resolve("node_modules/.bin/cordova");
const wrapperSourceDir = resolve(cordovaDir, "gradle-wrapper");
const wrapperTargetDir = resolve(cordovaDir, "platforms/android/tools");

function getOrigin() {
  const configured =
    process.env.CORDOVA_API_ORIGIN ??
    process.env.REPLIT_INTERNAL_APP_DOMAIN ??
    process.env.REPLIT_DEV_DOMAIN;

  if (!configured) {
    throw new Error(
      "Set CORDOVA_API_ORIGIN to the deployed SMS Number URL before building Android.",
    );
  }

  const withScheme = /^https?:\/\//i.test(configured)
    ? configured
    : `https://${configured}`;
  return new URL(withScheme).origin;
}

function run(command, args, cwd, env = process.env) {
  const result = spawnSync(command, args, {
    cwd,
    env,
    stdio: "inherit",
  });

  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

function normalizeLocalAssetUrls(directory) {
  const localFiles = [];

  function collect(currentDir) {
    for (const entry of readdirSync(currentDir)) {
      const entryPath = resolve(currentDir, entry);
      if (statSync(entryPath).isDirectory()) {
        collect(entryPath);
      } else if (/\.(html?|js|mjs|css|json)$/i.test(entry)) {
        localFiles.push(entryPath);
      }
    }
  }

  collect(directory);

  for (const filePath of localFiles) {
    const original = readFileSync(filePath, "utf8");
    const normalized = original
      .replaceAll('"/_expo/', '"./expo/')
      .replaceAll("'/_expo/", "'./expo/")
      .replaceAll("`/_expo/", "`./expo/")
      .replaceAll('"./_expo/', '"./expo/')
      .replaceAll("'./_expo/", "'./expo/")
      .replaceAll("`./_expo/", "`./expo/")
      .replaceAll('"/assets/', '"./bundle-assets/')
      .replaceAll("' /assets/", "' ./bundle-assets/")
      .replaceAll("'/assets/", "'./bundle-assets/")
      .replaceAll("`/assets/", "`./bundle-assets/")
      .replaceAll('"./assets/', '"./bundle-assets/')
      .replaceAll("'./assets/", "'./bundle-assets/")
      .replaceAll("`./assets/", "`./bundle-assets/")
      .replaceAll("__node_modules", "node_modules")
      .replaceAll("/.pnpm/", "/pnpm/")
      .replaceAll('href="/favicon.ico"', 'href="./favicon.ico"');

    if (normalized !== original) {
      writeFileSync(filePath, normalized);
    }
  }
}

const apiOrigin = getOrigin();
const apiHost = new URL(apiOrigin).host;
const apiUrl =
  process.env.CORDOVA_API_URL ??
  process.env.EXPO_PUBLIC_API_URL ??
  apiOrigin;
const buildEnv = {
  ...process.env,
  EXPO_PUBLIC_DOMAIN: apiHost,
  EXPO_PUBLIC_API_URL: apiUrl,
  REPLIT_INTERNAL_APP_DOMAIN: apiHost,
};
buildEnv.PATH = `${resolve(cordovaDir, "gradle-bin")}${delimiter}${process.env.PATH ?? ""}`;
const localSdk = resolve(".android-sdk");
if (existsSync(localSdk)) {
  buildEnv.ANDROID_HOME ??= localSdk;
  buildEnv.ANDROID_SDK_ROOT ??= localSdk;
  buildEnv.PATH = [
    resolve(localSdk, "platform-tools"),
    resolve(localSdk, "cmdline-tools/latest/bin"),
    buildEnv.PATH,
  ].join(delimiter);
}

run("pnpm", ["--filter", "@workspace/mobile", "run", "build"], root, buildEnv);

if (!existsSync(resolve(webDir, "index.html"))) {
  throw new Error("The mobile web export did not produce static-build/index.html.");
}

const wwwDir = resolve(cordovaDir, "www");
rmSync(wwwDir, { recursive: true, force: true });
cpSync(webDir, wwwDir, { recursive: true });
// Android Gradle's default asset filter excludes directories beginning with
// "_". Expo exports its entry bundle under "_expo" and puts many font/image
// files under "assets/__node_modules", so those directories would silently
// disappear from the APK. Use safe directory names inside the native package
// and rewrite the exported relative references below.
renameSync(resolve(wwwDir, "_expo"), resolve(wwwDir, "expo"));
renameSync(resolve(wwwDir, "assets"), resolve(wwwDir, "bundle-assets"));
renameSync(
  resolve(wwwDir, "bundle-assets/__node_modules"),
  resolve(wwwDir, "bundle-assets/node_modules"),
);
renameSync(
  resolve(wwwDir, "bundle-assets/node_modules/.pnpm"),
  resolve(wwwDir, "bundle-assets/node_modules/pnpm"),
);
normalizeLocalAssetUrls(wwwDir);

run(cordovaBin, ["prepare", "android"], cordovaDir, buildEnv);
mkdirSync(wrapperTargetDir, { recursive: true });
cpSync(wrapperSourceDir, wrapperTargetDir, { recursive: true, force: true });
const preparedWebDir = resolve(cordovaDir, "platforms/android/app/src/main/assets/www");
if (
  !existsSync(resolve(preparedWebDir, "expo/static/js/web")) ||
  !existsSync(resolve(preparedWebDir, "bundle-assets/node_modules/pnpm"))
) {
  throw new Error(
    "Cordova prepare dropped the exported JavaScript or asset directories from Android assets.",
  );
}
console.log(`Cordova web bundle prepared at ${wwwDir}`);